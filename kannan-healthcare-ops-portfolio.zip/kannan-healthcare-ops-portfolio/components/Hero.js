import FlowDots from "./FlowDots";
import { profile, flow } from "@/data/content";

export default function Hero() {
  return (
    <header className="mx-auto grid max-w-5xl items-center gap-12 px-5 pb-12 pt-10 sm:px-8 sm:pt-20 lg:grid-cols-[1.15fr_1fr]">
      <div>
        <p className="text-sm font-medium text-teal">{profile.name}</p>
        <h1 className="mt-4 font-serif text-4xl font-semibold leading-[1.1] tracking-tight sm:text-6xl">{profile.title}</h1>
        <p className="mt-6 max-w-xl font-serif text-lg leading-relaxed text-ink/80 sm:text-xl">{profile.statement}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <a href="#contact" className="rounded-md bg-teal px-5 py-3 text-sm font-semibold text-paper transition hover:opacity-90">Get in touch</a>
          <a href="#work" className="rounded-md border border-line px-5 py-3 text-sm font-semibold transition hover:border-teal">See results</a>
        </div>
      </div>
      <FlowDots before={flow.before} after={flow.after} />
    </header>
  );
}
