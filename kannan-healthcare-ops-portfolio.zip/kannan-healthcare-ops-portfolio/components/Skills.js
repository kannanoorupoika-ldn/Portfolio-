import Section from "./Section";
import { skills, education, languages } from "@/data/content";

export default function Skills() {
  return (
    <>
      <Section id="skills" title="Skills">
        <div className="grid gap-x-10 gap-y-8 sm:grid-cols-2">
          {skills.map((s) => (
            <div key={s.group}>
              <h3 className="font-semibold">{s.group}</h3>
              <p className="mt-1 leading-relaxed text-ink/75">{s.items.join(", ")}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 text-sm text-ink/70">Languages: {languages}</p>
      </Section>
      <Section id="education" title="Education and certifications">
        <ul className="divide-y divide-line border-y border-line">
          {education.map((e) => (
            <li key={e.name} className="flex flex-col gap-1 py-4 sm:flex-row sm:justify-between">
              <div><p className="font-medium">{e.name}</p><p className="text-ink/70">{e.org}</p></div>
              <p className="text-sm text-ink/60 sm:max-w-xs sm:text-right">{e.note}</p>
            </li>
          ))}
        </ul>
      </Section>
    </>
  );
}
