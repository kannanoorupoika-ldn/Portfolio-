import Section from "./Section";
import { cases } from "@/data/content";

export default function Cases() {
  return (
    <Section id="work" title="Selected results">
      <div className="grid gap-6 md:grid-cols-2">
        {cases.map((c, i) => (
          <article key={c.name} className={`rounded-lg border border-line bg-panel p-6 ${i === 0 ? "md:col-span-2" : ""}`}>
            <p className="text-sm text-ink/60">{c.where}</p>
            <h3 className="mt-1 font-serif text-2xl font-semibold">{c.name}</h3>
            <dl className="mt-4 space-y-3 text-[15px] leading-relaxed">
              <div><dt className="font-semibold">Problem</dt><dd className="text-ink/80">{c.problem}</dd></div>
              <div><dt className="font-semibold">What I did</dt><dd className="text-ink/80">{c.solution}</dd></div>
              <div><dt className="font-semibold text-teal">Outcome</dt><dd className="font-medium">{c.outcome}</dd></div>
            </dl>
            <p className="mt-4 text-sm text-ink/60">{c.tools.join(", ")}</p>
          </article>
        ))}
      </div>
    </Section>
  );
}
