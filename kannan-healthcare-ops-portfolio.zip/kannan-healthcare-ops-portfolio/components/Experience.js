import Section from "./Section";
import { experience } from "@/data/content";

export default function Experience() {
  return (
    <Section id="experience" title="Experience">
      <ol className="space-y-10 border-l border-line pl-6 sm:pl-8">
        {experience.map((e) => (
          <li key={e.org + e.role} className="relative">
            <span className="absolute -left-[31px] top-2 h-2.5 w-2.5 rounded-full bg-teal sm:-left-[39px]" />
            <p className="text-sm text-ink/60">{e.period}</p>
            <h3 className="font-serif text-xl font-semibold">{e.role}</h3>
            <p className="text-ink/70">{e.org}, {e.place}</p>
            <ul className="mt-3 max-w-2xl list-disc space-y-1.5 pl-5 leading-relaxed text-ink/85">
              {e.points.map((p) => <li key={p}>{p}</li>)}
            </ul>
          </li>
        ))}
      </ol>
    </Section>
  );
}
