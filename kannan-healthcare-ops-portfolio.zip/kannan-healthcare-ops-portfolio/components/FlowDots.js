"use client";
import { useEffect, useState } from "react";

// 100 enquiries. Filled dots show how many became consultations.
export default function FlowDots({ before, after }) {
  const [count, setCount] = useState(before);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return setCount(after);
    const t = setTimeout(() => setCount(after), 900);
    return () => clearTimeout(t);
  }, [after]);
  return (
    <figure aria-label={`Out of every 100 enquiries, consultations rose from ${before} to ${after}`}>
      <div className="grid grid-cols-10 gap-2 sm:gap-2.5">
        {Array.from({ length: 100 }, (_, i) => (
          <span
            key={i}
            style={{ transitionDelay: `${Math.max(0, i - before) * 12}ms` }}
            className={`dot aspect-square rounded-full ${i < count ? "bg-teal" : "bg-line"} ${i >= before && i < count ? "scale-110" : ""}`}
          />
        ))}
      </div>
      <figcaption className="mt-4 text-sm text-ink/70">
        Out of every 100 enquiries, consultations went from {before} to {after} at V Medicare.
      </figcaption>
    </figure>
  );
}
