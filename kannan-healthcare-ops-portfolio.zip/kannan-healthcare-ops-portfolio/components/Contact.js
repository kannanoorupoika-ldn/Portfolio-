import Section from "./Section";
import { profile } from "@/data/content";

export default function Contact() {
  const link = "underline decoration-line underline-offset-4 transition hover:decoration-teal";
  return (
    <Section id="contact" title="Let's talk">
      <p className="max-w-xl font-serif text-xl leading-relaxed">Open to {profile.openTo.join(", ")} roles, and to consulting conversations.</p>
      <ul className="mt-6 space-y-2">
        <li><a className={link} href={`mailto:${profile.email}`}>{profile.email}</a></li>
        <li><a className={link} href={`tel:${profile.phone}`}>{profile.phone}</a></li>
        <li><a className={link} href={profile.linkedin} target="_blank" rel="noreferrer">LinkedIn profile</a></li>
        <li className="text-ink/70">{profile.location}</li>
      </ul>
    </Section>
  );
}
