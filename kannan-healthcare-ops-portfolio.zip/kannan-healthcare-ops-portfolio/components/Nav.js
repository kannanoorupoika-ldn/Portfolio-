const links = [["work", "Results"], ["experience", "Experience"], ["skills", "Skills"], ["contact", "Contact"]];
export default function Nav() {
  return (
    <nav className="sticky top-0 z-10 border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3 sm:px-8">
        <a href="#" className="font-serif font-semibold">KMN</a>
        <ul className="flex gap-4 text-sm sm:gap-6">
          {links.map(([id, label]) => <li key={id}><a className="transition hover:text-teal" href={`#${id}`}>{label}</a></li>)}
        </ul>
      </div>
    </nav>
  );
}
