import "./globals.css";
import { Newsreader, Public_Sans } from "next/font/google";
import { profile } from "@/data/content";

const serif = Newsreader({ subsets: ["latin"], variable: "--font-serif" });
const sans = Public_Sans({ subsets: ["latin"], variable: "--font-sans" });

export const metadata = {
  title: `${profile.name} | ${profile.title}`,
  description: profile.statement,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable}`}>
      <body>{children}</body>
    </html>
  );
}
