import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import Section from "@/components/Section";
import Cases from "@/components/Cases";
import Experience from "@/components/Experience";
import Skills from "@/components/Skills";
import Contact from "@/components/Contact";
import { profile } from "@/data/content";

export default function Home() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Section id="about" title="About">
          <div className="max-w-2xl space-y-4 font-serif text-lg leading-relaxed">
            {profile.about.map((p) => <p key={p}>{p}</p>)}
          </div>
        </Section>
        <Cases />
        <Experience />
        <Skills />
        <Contact />
      </main>
      <footer className="border-t border-line py-8 text-center text-sm text-ink/60">{profile.name}</footer>
    </>
  );
}
