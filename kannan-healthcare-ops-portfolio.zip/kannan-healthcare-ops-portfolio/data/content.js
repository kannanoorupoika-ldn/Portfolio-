// Edit this file to update the whole site. All facts come from the candidate's CV and LinkedIn profile.
export const profile = {
  name: "Kannan Madhusoodanan Nair",
  title: "Healthcare Operations & Customer Success Leader",
  statement:
    "I redesign patient and customer journeys so more enquiries become consultations, and clinics run closer to full capacity.",
  location: "Central London, UK (on-site availability)",
  email: "kannanoorupoika@gmail.com",
  phone: "07442663207",
  linkedin: "https://www.linkedin.com/in/kannanmadhusoodanan-nair-4013961ba",
  about: [
    "I have 9+ years of experience across private healthcare, property and large-scale service operations. I combine hands-on clinic leadership with P&L oversight, and I hold an MBA and a CMI Level 7 in strategic leadership.",
    "My approach is practical: understand what the customer needs, find where the service journey breaks down, improve communication between customers and teams, and remove steps that cause delay or frustration.",
    "I am open to Customer Success, Operations and healthcare management roles, as well as consulting conversations.",
  ],
  openTo: ["Customer Success", "Healthcare Operations", "Account Management"],
};

// Numbers shown in the hero flow visual (from the CV: inquiry-to-consultation 22% -> 38%)
export const flow = { before: 22, after: 38 };

export const cases = [
  {
    name: "Patient journey redesign",
    where: "V Medicare Limited",
    problem: "Intake, enquiry and scheduling workflows lost potential patients before they reached a consultation.",
    solution: "Overhauled intake, enquiry and scheduling workflows to streamline the end-to-end client experience.",
    tools: ["Workflow design", "EHR / practice management", "CRM"],
    outcome: "Inquiry-to-consultation conversion rose from 22% to 38%.",
  },
  {
    name: "Capacity and room utilisation",
    where: "V Medicare Limited",
    problem: "Doctor, practitioner and room capacity was not matched across service lines.",
    solution: "Optimised capacity across service lines and managed budgets, KPIs and vendor and hospital partner agreements.",
    tools: ["Rota scheduling", "KPI tracking", "Vendor management"],
    outcome: "35% growth in net revenue and an 18% increase in operational margin.",
  },
  {
    name: "Multi-site operations and procurement",
    where: "Bovine Burger Ltd",
    problem: "High-volume multi-site operations needed tighter resource allocation and less waste.",
    solution: "Directed daily operations and standardised procurement, supplier agreements and labour scheduling.",
    tools: ["Procurement", "Labour scheduling", "Commercial management"],
    outcome: "34% increase in operational throughput.",
  },
  {
    name: "Large-scale event delivery",
    where: "V-Events",
    problem: "Concurrent projects with strict timelines and high service standards.",
    solution: "Directed operations, vendor contracts and cross-functional teams, and coordinated clients and workforce planning.",
    tools: ["Vendor contracts", "Workforce planning", "Client acquisition"],
    outcome: "Delivered 100+ projects for 2,000+ guests, with teams of 100+ employees.",
  },
];

export const experience = [
  {
    role: "General Manager, Healthcare Operations & Revenue",
    org: "V Medicare Limited",
    place: "London, UK / International",
    period: "2024 – Present",
    points: [
      "Lead a cross-functional team of 20+ clinical coordinators, administrators and partner leads, with clear KPIs, rotas and communication standards.",
      "Raised inquiry-to-consultation conversion from 22% to 38% by redesigning intake, enquiry and scheduling.",
      "Grew net revenue 35% and operational margin 18% by optimising doctor, practitioner and room capacity.",
      "Oversee compliance and governance in line with healthcare regulatory frameworks, with zero audit discrepancies and strict data confidentiality.",
    ],
  },
  {
    role: "Operations Lead & Commercial Manager",
    org: "Bovine Burger Ltd",
    place: "London, UK",
    period: "2023 – Present",
    points: [
      "Directed daily operations and resource allocation across multiple sites, achieving a 34% increase in operational throughput.",
      "Standardised procurement, supplier agreements and labour scheduling to improve profitability and cut waste.",
    ],
  },
  {
    role: "Finance & Operations Manager",
    org: "V Real Estates",
    place: "India",
    period: "2022 – 2023",
    points: [
      "Managed operational budgets, monitored expense variances and executed commercial agreements.",
      "Negotiated with media agencies to improve buying processes for digital advertising and media sales.",
    ],
  },
  {
    role: "Assistant Manager, Operations & Client Acquisition",
    org: "V-Events",
    place: "India",
    period: "2017 – 2022",
    points: ["Directed operations, vendor contracts and teams across 100+ projects involving 2,000+ guests."],
  },
];

export const skills = [
  { group: "Clinic operations", items: ["Patient flow management", "Multidisciplinary rota scheduling", "Capacity and room utilisation", "Service delivery"] },
  { group: "Customer success", items: ["Retention", "Onboarding", "Escalation management", "Customer relationship management", "Lead-to-consultation optimisation"] },
  { group: "Leadership", items: ["Cross-functional management", "Performance KPIs", "Coaching", "Recruitment and staff development"] },
  { group: "Compliance and governance", items: ["Healthcare regulatory frameworks (DHA/UK)", "Quality assurance", "Patient privacy and EHR protocols"] },
  { group: "Finance and commercial", items: ["P&L administration", "Operational budgeting", "Cost control", "Variance analysis", "Vendor management"] },
  { group: "Systems", items: ["EHR / EMR", "Practice management systems", "Zoho CRM", "HubSpot", "Advanced MS Excel", "MS Office"] },
];

export const education = [
  { name: "MBA, Business Administration and Management", org: "University of West London", note: "Strategic Management, Operations Strategy, Business Analytics" },
  { name: "Level 7, Strategic Management and Leadership", org: "Chartered Management Institute", note: "2023" },
  { name: "MCom, Finance", org: "University of Kerala", note: "2018 – 2020" },
  { name: "Postgraduate Diploma, Human Resources Management", org: "Alagappa University", note: "2021 – 2022" },
  { name: "Bachelor of Commerce", org: "University of Kerala", note: "2014 – 2018" },
];

export const languages = "English (fluent), Hindi (fluent), Malayalam (native), Tamil (conversational)";
