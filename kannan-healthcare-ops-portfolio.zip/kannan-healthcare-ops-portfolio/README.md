# Kannan Madhusoodanan Nair – Portfolio

A responsive portfolio for a healthcare operations and customer success leader. It uses a patient-flow visual in the hero because the candidate's strongest result is raising inquiry-to-consultation conversion from 22% to 38%.

## Stack
Next.js 14 (App Router), React 18, Tailwind CSS 3. No API keys or environment variables. Dark mode follows the system setting.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000. Fonts (Newsreader, Public Sans) load from Google Fonts via `next/font`, so the first run needs internet access.

## Customise
All content lives in `data/content.js`: profile, hero numbers, results, experience, skills and education. Colours are CSS variables in `app/globals.css`. Layout pieces are in `components/`.

## Deploy
Push to GitHub and import the repo in Vercel, or run `npm run build && npm start`.

## Suggested repository name
`kannan-healthcare-ops-portfolio`
